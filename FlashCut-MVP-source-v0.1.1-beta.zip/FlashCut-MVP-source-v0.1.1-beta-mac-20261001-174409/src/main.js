const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

let window;
const exportQueue = [];
const activeJobs = new Map();
let maxConcurrent = 3;
// Cache actual hardware checks, rather than trusting FFmpeg's compiled-in
// encoder list. A driver can make an encoder unavailable even when it appears
// in that list.
const encoderAvailability = new Map();
const emit = (channel, payload) => window?.webContents.send(channel, payload);
function executableName(name) { return process.platform === 'win32' ? `${name}.exe` : name; }
function ffmpegPath() { const custom = process.env.FLASHCUT_FFMPEG; if (custom && fs.existsSync(custom)) return custom; const bundled = path.join(process.resourcesPath, executableName('ffmpeg')); return fs.existsSync(bundled) ? bundled : executableName('ffmpeg'); }
function ffprobePath() { const sibling = path.join(path.dirname(ffmpegPath()), executableName('ffprobe')); return fs.existsSync(sibling) ? sibling : executableName('ffprobe'); }
function run(binary, args) { return spawnSync(binary, args, { encoding: 'utf8', windowsHide: true }); }
function escapeConcat(value) { return value.replace(/'/g, "'\\''"); }
function isWhole(segment) { return Math.abs(segment.in || 0) < .001 && Math.abs((segment.out ?? segment.duration) - segment.duration) < .001; }
function probeEncoder(name) {
  if (encoderAvailability.has(name)) return encoderAvailability.get(name);
  // `-encoders` only says FFmpeg was compiled with an encoder. Verify the GPU
  // and driver with one real 1080p60 frame—the same shape FlashCut exports.
  // Some AMD AMF drivers reject very tiny test frames despite working perfectly
  // at normal video sizes. The timeout prevents a damaged driver from freezing
  // FlashCut.
  const result = spawnSync(ffmpegPath(), [
    '-hide_banner', '-loglevel', 'error', '-f', 'lavfi',
    '-i', 'color=c=black:s=1920x1080:r=60', '-frames:v', '1',
    '-c:v', name, '-f', 'null', '-'
  ], { encoding: 'utf8', windowsHide: true, timeout: 8000 });
  const available = result.status === 0;
  const diagnostic = available ? 'ready' : (
    result.error?.code === 'ETIMEDOUT' ? 'hardware check timed out' :
      (result.stderr || result.error?.message || `encoder exited with code ${result.status ?? 'unknown'}`).trim()
  );
  const probe = { available, diagnostic };
  encoderAvailability.set(name, probe);
  return probe;
}
function hasEncoder(name) { return probeEncoder(name).available; }
function preferredHardwareEncoder() {
  // AMF first so a computer with an AMD card uses that card, rather than a
  // secondary Intel integrated GPU. The same real test is used by the banner,
  // queue, and export command so they can never disagree.
  return ['h264_amf', 'h264_nvenc', 'h264_qsv'].find(hasEncoder) || null;
}
function makeFilter(segments) {
  const video = [], audio = [], joins = [];
  segments.forEach((s, i) => {
    const end = s.out ?? s.duration;
    video.push(`[${i}:v]trim=start=${s.in || 0}:end=${end},setpts=PTS-STARTPTS,scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black,fps=60,setsar=1,format=yuv420p[v${i}]`);
    audio.push(`[${i}:a]atrim=start=${s.in || 0}:end=${end},asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a${i}]`);
    joins.push(`[v${i}][a${i}]`);
  });
  return `${video.join(';')};${audio.join(';')};${joins.join('')}concat=n=${segments.length}:v=1:a=1[outv][outa]`;
}
function thumbnailFor(file, seconds = 0) {
  const folder = path.join(app.getPath('userData'), 'thumbnails');
  fs.mkdirSync(folder, { recursive: true });
  const point = Math.max(0, Number(seconds) || 0).toFixed(3);
  const output = path.join(folder, `${crypto.createHash('sha1').update(`${file}:${point}`).digest('hex')}-accurate-v2-frame.jpg`);
  if (!fs.existsSync(output)) {
    const result = run(ffmpegPath(), ['-y', '-i', file, '-ss', point, '-map', '0:v:0', '-frames:v', '1', '-vf', 'scale=320:-2', '-q:v', '4', output]);
    if (result.status !== 0) return null;
  }
  return output;
}
async function thumbnailForAsync(file, seconds = 0) {
  const folder = path.join(app.getPath('userData'), 'thumbnails');
  fs.mkdirSync(folder, { recursive: true });
  const point = Math.max(0, Number(seconds) || 0).toFixed(3);
  const output = path.join(folder, `${crypto.createHash('sha1').update(`${file}:${point}`).digest('hex')}-accurate-v2-frame.jpg`);
  if (fs.existsSync(output)) return output;
  const result = await new Promise(resolve => {
    const child = spawn(ffmpegPath(), ['-y', '-i', file, '-ss', point, '-map', '0:v:0', '-frames:v', '1', '-vf', 'scale=320:-2', '-q:v', '4', output], { windowsHide: true });
    child.on('error', () => resolve(false)); child.on('close', code => resolve(code === 0));
  });
  return result ? output : null;
}
async function framesForSegment(file, start, end, count = 7) {
  const safeStart = Math.max(0, Number(start) || 0), safeEnd = Math.max(safeStart, Number(end) || safeStart);
  const total = Math.max(2, Math.min(60, Number(count) || 7));
  const frames = [];
  for (let index = 0; index < total; index += 1) {
    const frame = await thumbnailForAsync(file, safeStart + ((safeEnd - safeStart) * index / (total - 1)));
    if (frame) frames.push(frame);
  }
  return frames;
}
function snapshotQueue() { return { active: [...activeJobs.values()].map(job => ({ id: job.id, projectName: job.projectName, output: job.output, detail: job.detail, resource: job.resource, state: 'rendering' })), waiting: exportQueue.map(j => ({ id: j.id, projectName: j.projectName, output: j.output, resource: j.resource || resourceFor(j), state: 'waiting' })), maxConcurrent }; }
function publishQueue() { emit('queue-update', snapshotQueue()); }
function buildArgs(job, temp, encoderOverride) {
  const smart = job.mode === 'smart' && job.segments.every(isWhole);
  if (smart) { const list = path.join(temp, 'timeline.txt'); fs.writeFileSync(list, job.segments.map(s => `file '${escapeConcat(s.path)}'`).join('\n')); return { smart, args: ['-y', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', '-movflags', '+faststart', job.output] }; }
  const encoder = encoderOverride || preferredHardwareEncoder() || 'libx264';
  const args = ['-y']; job.segments.forEach(s => args.push('-i', s.path));
  args.push('-filter_complex', makeFilter(job.segments), '-map', '[outv]', '-map', '[outa]', '-r', '60', '-c:v', encoder);
  if (encoder === 'h264_nvenc') args.push('-preset', 'p1', '-cq', '23'); else if (encoder === 'libx264') args.push('-preset', 'veryfast', '-crf', '20');
  args.push('-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', job.output);
  return { smart, encoder, args };
}
function resourceFor(job) {
  if (job.resource) return job.resource;
  if (job.mode === 'smart' && job.segments.every(isWhole)) return job.resource = 'copy';
  return job.resource = preferredHardwareEncoder() ? 'gpu' : 'cpu';
}
function canStart(job) {
  if (activeJobs.size >= maxConcurrent) return false;
  const active = [...activeJobs.values()].map(resourceFor), resource = resourceFor(job);
  if (resource === 'gpu') return !active.includes('gpu');
  if (resource === 'cpu') return !active.includes('cpu') && active.length < 2;
  return active.filter(kind => kind === 'copy').length < 2;
}
function processQueue() {
  let started = true;
  while (started && activeJobs.size < maxConcurrent) {
    started = false;
    const index = exportQueue.findIndex(canStart);
    if (index >= 0) { startJob(exportQueue.splice(index, 1)[0]); started = true; }
  }
}
function startJob(job) {
  const resource = resourceFor(job); job.detail = resource === 'copy' ? 'Preparing Smart Copy...' : resource === 'gpu' ? 'Preparing GPU render...' : 'Preparing CPU render...'; activeJobs.set(job.id, job); publishQueue();
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'flashcut-')); let command;
  try { command = buildArgs(job, temp); } catch (error) { completeJob(job.id, false, error.message, temp); return; }
  const launch = (nextCommand, canFallback) => {
    job.detail = nextCommand.smart ? 'Smart Copy: no video re-encode.' : nextCommand.encoder === 'libx264' ? 'CPU fallback render in progress...' : 'Rendering with hardware acceleration...'; publishQueue();
    const child = spawn(ffmpegPath(), nextCommand.args, { windowsHide: true }); let stderr = '', fallbackStarted = false;
    const fallbackToCpu = () => {
      if (!canFallback || fallbackStarted) return false;
      fallbackStarted = true;
      job.resource = 'cpu';
      job.detail = 'Hardware encoder unavailable — switching to CPU render...'; publishQueue();
      launch(buildArgs(job, temp, 'libx264'), false);
      return true;
    };
    child.stderr.on('data', chunk => { stderr += chunk; const match = chunk.toString().match(/time=(\d\d:\d\d:\d\d\.\d+)/); if (match && activeJobs.has(job.id)) { job.detail = `Rendering ${match[1]}`; publishQueue(); } });
    child.on('error', error => { if (!fallbackToCpu()) completeJob(job.id, false, error.message, temp); });
    child.on('close', code => { if (fallbackStarted) return; if (code === 0) completeJob(job.id, true, 'Export complete.', temp); else if (!fallbackToCpu()) completeJob(job.id, false, stderr.slice(-800) || `FFmpeg exited with code ${code}`, temp); });
  };
  launch(command, !command.smart && command.encoder !== 'libx264');
}
function completeJob(id, ok, detail, temp) { const job = activeJobs.get(id); if (!job) return; fs.rmSync(temp, { recursive: true, force: true }); activeJobs.delete(id); emit('queue-finished', { id, ok, detail, output: job.output, projectName: job.projectName }); publishQueue(); processQueue(); }

ipcMain.handle('choose-files', async () => {
  const result = await dialog.showOpenDialog(window, { properties: ['openFile', 'multiSelections'], filters: [{ name: 'Video', extensions: ['mp4', 'mov', 'mkv', 'avi', 'webm', 'm4v'] }] });
  if (result.canceled) return [];
  return result.filePaths.map(file => { const answer = run(ffprobePath(), ['-v', 'error', '-show_entries', 'format=duration:stream=codec_name,codec_type,width,height,r_frame_rate', '-of', 'json', file]); if (answer.error || answer.status !== 0) throw new Error('FFprobe was not found. Install FFmpeg or set FLASHCUT_FFMPEG to the FFmpeg executable.'); const info = JSON.parse(answer.stdout), video = info.streams.find(s => s.codec_type === 'video') || {}; return { path: file, name: path.basename(file), duration: Number(info.format.duration || 0), codec: video.codec_name || 'unknown', width: video.width, height: video.height, fps: video.r_frame_rate || '?', thumbnail: thumbnailFor(file) }; });
});
ipcMain.handle('save-as', async (_, suggested) => { const result = await dialog.showSaveDialog(window, { defaultPath: suggested, filters: [{ name: 'MP4 video', extensions: ['mp4'] }] }); return result.canceled ? null : result.filePath; });
ipcMain.handle('system-info', () => {
  const amf = probeEncoder('h264_amf');
  const nvenc = probeEncoder('h264_nvenc');
  const qsv = probeEncoder('h264_qsv');
  const selectedEncoder = preferredHardwareEncoder();
  return {
    ffmpeg: ffmpegPath(),
    selectedEncoder,
    amf: amf.available,
    nvenc: nvenc.available,
    qsv: qsv.available,
    diagnostics: { amf: amf.diagnostic, nvenc: nvenc.diagnostic, qsv: qsv.diagnostic }
  };
});
ipcMain.handle('hydrate-thumbnails', (_, files) => Object.fromEntries(files.map(file => [file, thumbnailFor(file)])));
ipcMain.handle('thumbnail-at', async (_, file, seconds) => thumbnailForAsync(file, seconds));
ipcMain.handle('segment-frames', async (_, file, start, end, count) => framesForSegment(file, start, end, count));
ipcMain.handle('queue-export', (_, job) => { if (!job.segments?.length) throw new Error('Add at least one clip to the timeline.'); if (!job.output) throw new Error('Choose an export location.'); exportQueue.push({ ...job, id: `${Date.now()}-${Math.random().toString(36).slice(2)}` }); publishQueue(); processQueue(); return snapshotQueue(); });
ipcMain.handle('queue-status', () => snapshotQueue());
ipcMain.handle('set-export-concurrency', (_, count) => { maxConcurrent = Math.max(1, Math.min(99, Number(count) || 1)); processQueue(); publishQueue(); return snapshotQueue(); });

app.whenReady().then(() => { window = new BrowserWindow({ width: 1440, height: 860, minWidth: 1040, minHeight: 680, backgroundColor: '#0b1020', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true } }); window.loadFile(path.join(__dirname, 'renderer', 'index.html')); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
