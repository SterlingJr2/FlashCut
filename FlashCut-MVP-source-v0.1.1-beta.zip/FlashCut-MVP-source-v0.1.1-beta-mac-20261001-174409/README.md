# FlashCut

FlashCut is a local Windows editor deliberately optimized for fast 1080p60 delivery.

## What the MVP does

- Import MP4, MOV, MKV, AVI, WebM, and M4V files.
- Builds an ordered timeline, with selection, splitting, clip removal, and left/right rearrangement.
- **Smart Copy** performs an FFmpeg concat stream copy for whole clips. This does not re-encode video and is the path capable of exceptionally fast exports when source clips are compatible.
- **Fast Render** applies splits and uses NVIDIA NVENC, Intel Quick Sync, or AMD AMF when available; otherwise it falls back to a fast CPU H.264 encode.

## Run locally

1. Install the current Windows build of [FFmpeg](https://ffmpeg.org/download.html), and make `ffmpeg.exe` and `ffprobe.exe` available on your `PATH`. Alternatively, set `FLASHCUT_FFMPEG` to the absolute path of `ffmpeg.exe`.
2. Install Node.js LTS, then open PowerShell in this folder.
3. Run `npm install` and then `npm start`.

To make a single portable executable, run `npm run package:win` after installation. The file will be written beneath `dist/`.

## Speed reality

A 40-minute 1080p60 export in two minutes is 20× realtime. Smart Copy can exceed that easily, but only when clips are full, compatible streams. Fast Render can approach it on a high-end GPU with simple edits; it is intentionally not promised for effect-heavy, mixed-codec, or slow-storage projects.

## Current intentional constraints

The first MVP handles normal audio-bearing source clips. It does not yet provide transitions, titles, color tools, waveform editing, proxy media, or automatic codec-normalization before Smart Copy. The app routes any split through Fast Render, which protects export correctness.
