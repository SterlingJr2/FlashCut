const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('flashcut', {
  chooseFiles: () => ipcRenderer.invoke('choose-files'),
  saveAs: name => ipcRenderer.invoke('save-as', name),
  inspectSystem: () => ipcRenderer.invoke('system-info'),
  hydrateThumbnails: files => ipcRenderer.invoke('hydrate-thumbnails', files),
  thumbnailAt: (file, seconds) => ipcRenderer.invoke('thumbnail-at', file, seconds),
  segmentFrames: (file, start, end, count) => ipcRenderer.invoke('segment-frames', file, start, end, count),
  queueExport: job => ipcRenderer.invoke('queue-export', job),
  queueStatus: () => ipcRenderer.invoke('queue-status'),
  onQueueUpdate: fn => ipcRenderer.on('queue-update', (_, queue) => fn(queue)),
  onQueueFinished: fn => ipcRenderer.on('queue-finished', (_, result) => fn(result)),
  fileUrl: file => `file:///${encodeURI(file.replace(/\\/g, '/'))}`
});
