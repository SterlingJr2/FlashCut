# FlashCut macOS beta build

FlashCut's app code is cross-platform and is ready to package for macOS. A Mac
is required for the last build step because a Windows computer cannot create a
reliable macOS `.app` bundle or supply the macOS FFmpeg executables.

On a Mac, place executable Universal macOS builds of `ffmpeg` and `ffprobe` in
`vendor/ffmpeg/macos/`, then run:

```bash
chmod +x vendor/ffmpeg/macos/ffmpeg vendor/ffmpeg/macos/ffprobe
npm ci
npm run package:mac
```

The result is a ZIP in `dist/`. Use `npm run package:mac:apple` for Apple
Silicon only or `npm run package:mac:intel` for Intel-only builds. Universal
FFmpeg binaries let the standard macOS package work on both kinds of Macs.

For public distribution, sign and notarize the app and bundled FFmpeg binaries
with an Apple Developer ID; otherwise macOS will warn beta testers before they
open it.
