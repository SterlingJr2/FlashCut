const $ = selector => document.querySelector(selector);
const PLAYER = $('#player');
const storageKey = 'flashcut-projects-v2';
const PIXELS_PER_SECOND = 60, TILE_SECONDS = 2, TILE_WIDTH = PIXELS_PER_SECOND * TILE_SECONDS;
const tileRequests = new Set();
let projects = loadProjects();
let activeId = projects[0].id;
let previewId = null;
let queuedAutoplay = false;
let pendingSeek = null;
let draggingPlayhead = false;
let suppressClipClickUntil = 0;
let queue = { active: [], waiting: [] };

function newProject(name = `Project ${projects.length + 1}`) { return { id: crypto.randomUUID(), name, media: [], timeline: [], selected: null, playhead: 0 }; }
function loadProjects() { try { const saved = JSON.parse(localStorage.getItem(storageKey)); return Array.isArray(saved) && saved.length ? saved : [newProject('Project 1')]; } catch { return [newProject('Project 1')]; } }
function saveProjects() { localStorage.setItem(storageKey, JSON.stringify(projects)); }
function project() { return projects.find(p => p.id === activeId); }
function seconds(value) { value = Math.max(0, value || 0); const mins = Math.floor(value / 60), secs = Math.floor(value % 60), tenths = Math.floor(value * 10) % 10; return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${tenths}`; }
function duration(segment) { return (segment.out ?? segment.duration) - (segment.in || 0); }
function selectedIndex() { return project().timeline.findIndex(s => s.id === project().selected); }
function clipFrom(media) { return { ...media, id: crypto.randomUUID(), in: 0, out: media.duration }; }
function currentSegment() { return project().timeline[selectedIndex()]; }

function render() {
  const p = project();
  $('#project-tabs').innerHTML = projects.map(item => `<button class="project-tab ${item.id === activeId ? 'active' : ''}" data-project="${item.id}">${item.name}</button>`).join('');
  $('#project-tabs').querySelectorAll('[data-project]').forEach(tab => tab.onclick = () => switchProject(tab.dataset.project));
  $('#project-title').textContent = p.name;
  $('#total-duration').textContent = seconds(p.timeline.reduce((total, s) => total + duration(s), 0));
  $('#media').classList.toggle('empty', !p.media.length);
  $('#media').innerHTML = p.media.length ? p.media.map((item, index) => `<div class="media-item" draggable="true" data-media="${index}">${item.thumbnail ? `<img src="${window.flashcut.fileUrl(item.thumbnail)}" alt="">` : '<div class="thumbnail-placeholder">VIDEO</div>'}<b>${item.name}</b><span>${item.width || '?'}x${item.height || '?'} | ${seconds(item.duration)}</span></div>`).join('') : 'Import clips, then drag them to the timeline.';
  $('#media').querySelectorAll('.media-item').forEach(item => item.ondragstart = event => event.dataTransfer.setData('media-index', item.dataset.media));
  const lane = $('#timeline');
  lane.classList.toggle('empty', !p.timeline.length);
  lane.innerHTML = p.timeline.length ? `${p.timeline.map((item, index) => `<button class="clip ${item.id === p.selected ? 'selected' : ''}" draggable="true" data-id="${item.id}" style="width:${Math.min(180, Math.max(54, duration(item) * 1.25))}px"><div class="clip-copy"><b>${index + 1}. ${item.name}</b><span>${seconds(item.in || 0)} - ${seconds(item.out ?? item.duration)}</span></div></button>`).join('')}<i id="playhead-marker"></i>` : 'Drag media here to build this project.';
  lane.querySelectorAll('.clip').forEach(item => {
    item.onclick = event => { if (Date.now() >= suppressClipClickUntil) seekClip(item.dataset.id, event.clientX); };
    item.ondragstart = event => { item.classList.add('dragging'); event.dataTransfer.setData('segment-id', item.dataset.id); };
    item.ondragend = () => { item.classList.remove('dragging'); suppressClipClickUntil = Date.now() + 180; };
  });
  positionMarker();
  $('#playhead').textContent = seconds(p.playhead);
  renderQueue(); saveProjects();
}
function renderQueue() {
  const entries = [...(Array.isArray(queue.active) ? queue.active : queue.active ? [queue.active] : []), ...queue.waiting].filter(Boolean);
  $('#queue-count').textContent = entries.length;
  $('#queue').classList.toggle('empty', !entries.length);
  $('#queue').innerHTML = entries.length ? entries.map(item => `<div class="queue-item ${item.state === 'rendering' ? 'running' : ''}"><b>${item.projectName}</b><span>${item.state === 'rendering' ? item.detail : `Waiting · ${item.resource === 'copy' ? 'Smart Copy' : item.resource === 'gpu' ? 'GPU render' : 'CPU render'}`}</span></div>`).join('') : 'No exports queued.';
}
function positionMarker() {
  const p = project(), lane = $('#timeline'), marker = $('#playhead-marker'), clip = lane.querySelector(`.clip[data-id="${p.selected}"]`), segment = currentSegment();
  if (!marker || !clip || !segment) return;
  const fraction = Math.max(0, Math.min(1, (p.playhead - (segment.in || 0)) / duration(segment)));
  marker.style.left = `${clip.offsetLeft + clip.offsetWidth * fraction}px`;
}
function switchProject(id) {
  activeId = id; previewId = null; PLAYER.pause(); PLAYER.removeAttribute('src'); PLAYER.load();
  $('#preview-label').textContent = 'Select a clip to preview.'; render();
}
function selectSegment(id, loadPreview) {
  const p = project(), segment = p.timeline.find(s => s.id === id); if (!segment) return;
  p.selected = id; p.playhead = Math.max(segment.in || 0, Math.min(segment.out ?? segment.duration, p.playhead));
  if (loadPreview) loadSegment(selectedIndex(), false, p.playhead); render();
}
function seekClip(id, clientX) {
  const p = project(), segment = p.timeline.find(s => s.id === id), clip = $('#timeline').querySelector(`.clip[data-id="${id}"]`); if (!segment || !clip) return;
  const box = clip.getBoundingClientRect();
  p.selected = id; p.playhead = (segment.in || 0) + Math.max(0, Math.min(1, (clientX - box.left) / box.width)) * duration(segment);
  if (previewId === id && PLAYER.readyState) PLAYER.currentTime = p.playhead; else loadSegment(selectedIndex(), false, p.playhead);
  render();
}
function loadSegment(index, autoplay = false, seek) {
  const p = project(), segment = p.timeline[index]; if (!segment) return;
  previewId = segment.id; queuedAutoplay = autoplay; pendingSeek = seek ?? segment.in ?? 0;
  PLAYER.pause(); PLAYER.src = window.flashcut.fileUrl(segment.path); PLAYER.load();
  $('#preview-label').textContent = `${segment.name} · ${seconds(segment.in || 0)} - ${seconds(segment.out ?? segment.duration)}`;
}
function addMedia(files) {
  const p = project(); files.forEach(file => p.media.push(file)); render();
}
function tileCount(segment) { return Math.max(1, Math.ceil(duration(segment) / TILE_SECONDS)); }
function renderVisibleTiles() {
  const p = project(), lane = $('#timeline'), left = lane.scrollLeft, right = left + lane.clientWidth;
  lane.querySelectorAll('.clip').forEach(clip => {
    const segment = p.timeline.find(item => item.id === clip.dataset.id), layer = clip.querySelector('.frame-strip'); if (!segment || !layer) return;
    const start = Math.max(0, Math.floor((left - clip.offsetLeft) / TILE_WIDTH) - 1), end = Math.min(tileCount(segment) - 1, Math.ceil((right - clip.offsetLeft) / TILE_WIDTH) + 1);
    if (end < start) { layer.innerHTML = ''; return; }
    layer.innerHTML = Array.from({ length: end - start + 1 }, (_, offset) => {
      const index = start + offset, at = (segment.in || 0) + index * TILE_SECONDS, key = at.toFixed(3), image = segment.timelineTiles?.[key], width = Math.min(TILE_WIDTH, Math.max(1, duration(segment) * PIXELS_PER_SECOND - index * TILE_WIDTH));
      if (!image) requestTimelineTile(segment, key, at);
      return image ? `<img class="timeline-tile" src="${window.flashcut.fileUrl(image)}" style="left:${index * TILE_WIDTH}px;width:${width}px" alt="">` : `<i class="timeline-tile tile-loading" style="left:${index * TILE_WIDTH}px;width:${width}px"></i>`;
    }).join('');
  });
}
async function requestTimelineTile(segment, key, at) {
  const requestKey = `${segment.id}:${key}`; if (tileRequests.has(requestKey) || segment.timelineTiles?.[key]) return;
  tileRequests.add(requestKey);
  try { const thumbnail = await window.flashcut.thumbnailAt(segment.path, at); if (thumbnail) { segment.timelineTiles ||= {}; segment.timelineTiles[key] = thumbnail; renderVisibleTiles(); } }
  catch (error) { $('#status').textContent = `Could not generate timeline frame: ${error.message}`; }
  finally { tileRequests.delete(requestKey); }
}
function setPlayheadFromPointer(event) {
  const target = document.elementsFromPoint(event.clientX, event.clientY).find(element => element.classList?.contains('clip')); if (!target) return;
  const p = project(), segment = p.timeline.find(s => s.id === target.dataset.id), box = target.getBoundingClientRect();
  p.selected = segment.id; p.playhead = (segment.in || 0) + Math.max(0, Math.min(1, (event.clientX - box.left) / box.width)) * duration(segment);
  $('#playhead').textContent = seconds(p.playhead); positionMarker();
}
function nudgePlayhead(direction, step = 1 / 60) {
  const p = project(), segment = currentSegment();
  if (!segment) return $('#status').textContent = 'Select a clip first.';
  p.playhead = Math.max(segment.in || 0, Math.min(segment.out ?? segment.duration, p.playhead + direction * step));
  $('#playhead').textContent = seconds(p.playhead); positionMarker();
  if (previewId === segment.id && PLAYER.readyState) PLAYER.currentTime = p.playhead;
}
function deleteSelected() {
  const p = project(), index = selectedIndex(); if (index < 0) return;
  const deleted = p.timeline.splice(index, 1)[0];
  const next = p.timeline[index] || p.timeline[index - 1]; p.selected = next?.id || null;
  if (previewId === deleted.id) { previewId = null; PLAYER.pause(); PLAYER.removeAttribute('src'); PLAYER.load(); }
  render();
}

const manager = $('#project-manager');
function renderProjectManager() {
  $('#project-list').innerHTML = projects.map(item => `<div class="project-row ${item.id === activeId ? 'active' : ''}" data-project-row="${item.id}"><strong>${item.name}</strong><span>${item.timeline.length} timeline clip${item.timeline.length === 1 ? '' : 's'}</span><button data-open="${item.id}">Open</button><button data-rename="${item.id}">Rename</button><button data-delete="${item.id}" class="danger">Delete</button></div>`).join('');
  $('#project-list').querySelectorAll('[data-open]').forEach(button => button.onclick = () => { switchProject(button.dataset.open); manager.hidden = true; });
  $('#project-list').querySelectorAll('[data-rename]').forEach(button => button.onclick = () => { const row = button.closest('.project-row'), item = projects.find(p => p.id === button.dataset.rename); row.innerHTML = `<input class="rename-input" value="${item.name.replace(/"/g, '&quot;')}"><button data-save-rename="${item.id}" class="primary">Save</button><button data-cancel-rename="${item.id}">Cancel</button>`; row.querySelector('[data-cancel-rename]').onclick = renderProjectManager; row.querySelector('[data-save-rename]').onclick = () => { const name = row.querySelector('.rename-input').value.trim(); if (name) { item.name = name; render(); } renderProjectManager(); }; row.querySelector('.rename-input').focus(); });
  $('#project-list').querySelectorAll('[data-delete]').forEach(button => button.onclick = () => { if (projects.length === 1) return $('#status').textContent = 'Keep at least one project in your library.'; if (button.dataset.confirm !== 'yes') { button.dataset.confirm = 'yes'; button.textContent = 'Confirm delete'; return; } const item = projects.find(p => p.id === button.dataset.delete); projects = projects.filter(p => p.id !== item.id); if (activeId === item.id) activeId = projects[0].id; render(); renderProjectManager(); });
}
$('#projects-button').onclick = () => { renderProjectManager(); manager.hidden = false; };
$('#close-manager').onclick = () => manager.hidden = true;
manager.querySelector('.modal-backdrop').onclick = () => manager.hidden = true;
$('#create-project').onclick = () => { const input = $('#project-name-input'), item = newProject(input.value.trim() || `Project ${projects.length + 1}`); projects.push(item); activeId = item.id; previewId = null; input.value = ''; manager.hidden = true; render(); };
$('#add').onclick = async () => { try { addMedia(await window.flashcut.chooseFiles()); } catch (error) { $('#status').textContent = error.message; } };
$('#split').onclick = () => { const p = project(), index = selectedIndex(), segment = currentSegment(), at = p.playhead; if (!segment) return $('#status').textContent = 'Select a clip first.'; if (!(at > (segment.in || 0) && at < (segment.out ?? segment.duration))) return $('#status').textContent = 'Place the red playhead inside the selected clip.'; const right = { ...segment, id: crypto.randomUUID(), in: at, thumbnail: segment.thumbnail, timelineTiles: {} }; p.timeline[index] = { ...segment, out: at }; p.timeline.splice(index + 1, 0, right); p.selected = right.id; render(); $('#status').textContent = 'Split at the red playhead.'; };
$('#duplicate').onclick = () => { const p = project(), index = selectedIndex(); if (index < 0) return $('#status').textContent = 'Select a clip first.'; const copy = { ...p.timeline[index], id: crypto.randomUUID() }; p.timeline.splice(index + 1, 0, copy); p.selected = copy.id; render(); };
$('#remove').onclick = deleteSelected;
$('#up').onclick = () => { const p = project(), index = selectedIndex(); if (index > 0) { [p.timeline[index - 1], p.timeline[index]] = [p.timeline[index], p.timeline[index - 1]]; render(); } };
$('#down').onclick = () => { const p = project(), index = selectedIndex(); if (index >= 0 && index < p.timeline.length - 1) { [p.timeline[index + 1], p.timeline[index]] = [p.timeline[index], p.timeline[index + 1]]; render(); } };
$('#play').onclick = () => { const p = project(); if (!p.timeline.length) return $('#status').textContent = 'Add clips to the timeline first.'; if (PLAYER.paused) { const index = previewId ? p.timeline.findIndex(s => s.id === previewId) : Math.max(0, selectedIndex()); if (index < 0 || !PLAYER.src) loadSegment(index < 0 ? 0 : index, true, p.playhead); else PLAYER.play(); } else PLAYER.pause(); };
$('#export').onclick = async () => { const p = project(); if (!p.timeline.length) return $('#status').textContent = 'Add clips first.'; const output = await window.flashcut.saveAs(`${p.name.replace(/[<>:"/\\|?*]/g, '-')}.mp4`); if (!output) return; const mode = document.querySelector('input[name="mode"]:checked').value; await window.flashcut.queueExport({ projectName: p.name, segments: structuredClone(p.timeline), output, mode }); $('#status').textContent = `${p.name} added to the export queue.`; };

const lane = $('#timeline');
lane.onpointerdown = event => { if (!event.target.closest('#playhead-marker')) return; draggingPlayhead = true; lane.setPointerCapture(event.pointerId); setPlayheadFromPointer(event); event.preventDefault(); };
lane.onpointermove = event => { if (draggingPlayhead) setPlayheadFromPointer(event); };
function finishPlayheadDrag(event) {
  if (!draggingPlayhead) return;
  draggingPlayhead = false;
  if (lane.hasPointerCapture(event.pointerId)) lane.releasePointerCapture(event.pointerId);
  const p = project(), segment = currentSegment();
  if (segment) { if (previewId === segment.id && PLAYER.readyState) PLAYER.currentTime = p.playhead; else loadSegment(selectedIndex(), false, p.playhead); }
  render();
}
lane.onpointerup = finishPlayheadDrag;
lane.onpointercancel = finishPlayheadDrag;
lane.onscroll = positionMarker;
lane.ondragover = event => { event.preventDefault(); lane.classList.add('drop-ready'); };
lane.ondragleave = () => lane.classList.remove('drop-ready');
lane.ondrop = event => { event.preventDefault(); lane.classList.remove('drop-ready'); const p = project(), target = event.target.closest('.clip'), insertAt = target ? p.timeline.findIndex(s => s.id === target.dataset.id) : p.timeline.length, segmentId = event.dataTransfer.getData('segment-id'), mediaIndex = event.dataTransfer.getData('media-index'); if (segmentId) { const from = p.timeline.findIndex(s => s.id === segmentId), moved = p.timeline.splice(from, 1)[0]; p.timeline.splice(from < insertAt ? insertAt - 1 : insertAt, 0, moved); p.selected = moved.id; } else if (mediaIndex !== '') { const clip = clipFrom(p.media[Number(mediaIndex)]); clip.timelineTiles = {}; p.timeline.push(clip); p.selected = clip.id; } render(); };
PLAYER.addEventListener('loadedmetadata', () => { const p = project(), segment = p.timeline.find(s => s.id === previewId); if (!segment) return; const at = Math.max(segment.in || 0, Math.min(segment.out ?? segment.duration, pendingSeek ?? segment.in ?? 0)); pendingSeek = null; p.playhead = at; PLAYER.currentTime = at; if (queuedAutoplay) { queuedAutoplay = false; PLAYER.play().catch(() => {}); } render(); });
PLAYER.addEventListener('timeupdate', () => { const p = project(), segment = p.timeline.find(s => s.id === previewId); if (!segment) return; p.playhead = PLAYER.currentTime; if (p.selected === segment.id) { $('#playhead').textContent = seconds(p.playhead); positionMarker(); } if (PLAYER.currentTime >= (segment.out ?? segment.duration) - .03) { const next = p.timeline.findIndex(s => s.id === segment.id) + 1; if (next < p.timeline.length) { p.selected = p.timeline[next].id; loadSegment(next, true, p.timeline[next].in || 0); } else PLAYER.pause(); } });
window.flashcut.onQueueUpdate(value => { queue = value; renderQueue(); });
window.flashcut.onQueueFinished(result => { $('#status').textContent = result.ok ? `${result.projectName} export complete.` : `Export failed: ${result.detail}`; });
window.flashcut.inspectSystem().then(info => {
  const labels = { h264_amf: 'AMD encoder ready', h264_nvenc: 'NVIDIA encoder ready', h264_qsv: 'Intel encoder ready' };
  const hardware = $('#hardware');
  hardware.textContent = labels[info.selectedEncoder] || 'CPU encoder';
  // Keep the exact hardware-check result available without cluttering the UI.
  hardware.title = info.selectedEncoder
    ? `FlashCut will export with ${info.selectedEncoder}.`
    : `No working hardware encoder was detected. AMD: ${info.diagnostics?.amf || 'not checked'} | NVIDIA: ${info.diagnostics?.nvenc || 'not checked'} | Intel: ${info.diagnostics?.qsv || 'not checked'}`;
}).catch(() => { $('#hardware').textContent = 'CPU encoder'; });
window.flashcut.queueStatus().then(value => { queue = value; renderQueue(); });
async function repairThumbnails() {
  const missing = [...new Set(projects.flatMap(p => p.media.filter(item => !item.thumbnail).map(item => item.path)))];
  if (!missing.length) return;
  try {
    const thumbnails = await window.flashcut.hydrateThumbnails(missing);
    projects.forEach(p => p.media.forEach(item => { if (thumbnails[item.path]) item.thumbnail = thumbnails[item.path]; }));
    render();
  } catch (error) { $('#status').textContent = `Could not generate thumbnails: ${error.message}`; }
}
window.addEventListener('keydown', event => {
  if (!manager.hidden || ['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName)) return;
  const key = event.key.toLowerCase();
  if (event.ctrlKey && key === 's') { event.preventDefault(); $('#split').click(); }
  else if (event.ctrlKey && key === 'd') { event.preventDefault(); $('#duplicate').click(); }
  else if (event.code === 'Space') { event.preventDefault(); $('#play').click(); }
  else if (event.key === 'Backspace' || event.key === 'Delete') { event.preventDefault(); deleteSelected(); }
  else if (event.key === 'ArrowLeft' || key === 'a') { event.preventDefault(); nudgePlayhead(-1, event.repeat ? 0.10 : event.shiftKey ? 1 : 1 / 60); }
  else if (event.key === 'ArrowRight' || key === 'd') { event.preventDefault(); nudgePlayhead(1, event.repeat ? 0.10 : event.shiftKey ? 1 : 1 / 60); }
});
render();
repairThumbnails();
